var namespaces_dup =
[
    [ "ProjektMagazyn", "namespace_projekt_magazyn.html", "namespace_projekt_magazyn" ]
];