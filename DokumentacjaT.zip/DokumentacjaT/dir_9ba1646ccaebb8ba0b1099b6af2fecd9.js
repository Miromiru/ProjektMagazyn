var dir_9ba1646ccaebb8ba0b1099b6af2fecd9 =
[
    [ "Form1.cs", "_form1_8cs.html", [
      [ "Form1", "class_projekt_magazyn_1_1_form1.html", "class_projekt_magazyn_1_1_form1" ]
    ] ],
    [ "Form1.Designer.cs", "_form1_8_designer_8cs.html", [
      [ "Form1", "class_projekt_magazyn_1_1_form1.html", "class_projekt_magazyn_1_1_form1" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", null ]
];