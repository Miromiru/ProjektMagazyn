var annotated_dup =
[
    [ "ProjektMagazyn", "namespace_projekt_magazyn.html", [
      [ "Form1", "class_projekt_magazyn_1_1_form1.html", "class_projekt_magazyn_1_1_form1" ]
    ] ]
];