var dir_98a47a8c16397e9ff86196bdfc4364f4 =
[
    [ "ProjektMagazyn", "dir_9ba1646ccaebb8ba0b1099b6af2fecd9.html", "dir_9ba1646ccaebb8ba0b1099b6af2fecd9" ]
];