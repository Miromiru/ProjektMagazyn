var hierarchy =
[
    [ "Form", null, [
      [ "ProjektMagazyn.Form1", "class_projekt_magazyn_1_1_form1.html", null ]
    ] ]
];